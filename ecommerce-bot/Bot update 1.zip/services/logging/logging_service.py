class LoggingService:
    def log_performance(self, request_id, metrics):
        pass

    def log_error(self, error, context):
        pass
