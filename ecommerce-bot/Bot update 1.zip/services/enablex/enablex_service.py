class EnableXService:
    async def send_message(self, to_number, message_type, content):
        # TODO: integrate with EnableX SDK / HTTP API
        pass
